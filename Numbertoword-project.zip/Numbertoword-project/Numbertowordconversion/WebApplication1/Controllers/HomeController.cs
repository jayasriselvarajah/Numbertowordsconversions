﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Text;

namespace NumberstoWords.Controllers
{
    public class HomeController : Controller
    {
        private readonly string[] unitsMap = { "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE" };
        private readonly string[] teensMap = { "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN" };
        private readonly string[] tensMap = { "", "", "TWENTY", "THIRTY", "FORTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY" };

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ConvertNumberToWords(string numberInput)
        {
            
            if (!decimal.TryParse(numberInput, out decimal number))
            {
                return BadRequest("Invalid number format.");
            }

            
            string wordsOutput = ConvertNumberToWords(number);

            return Ok(new { wordsOutput = wordsOutput });
        }



        private string ConvertNumberToWords(decimal number)
        {
            StringBuilder words = new StringBuilder();

            if (number < 0)
            {
                words.Append("MINUS ");
                number = Math.Abs(number);
            }

            long integerPart = (long)number;
            int decimalPart = (int)((number - integerPart) * 100);

            words.Append(ConvertToWords(integerPart));
            words.Append(" DOLLARS");

            if (decimalPart > 0)
            {
                words.Append(" AND ");
                words.Append(ConvertToWords(decimalPart));
                words.Append(" CENTS");
            }

            return words.ToString();
        }

        private string ConvertToWords(long number)
        {
            if (number < 10)
            {
                return unitsMap[number];
            }
            else if (number < 20)
            {
                return teensMap[number - 10];
            }
            else if (number < 100)
            {
                return tensMap[number / 10] + ((number % 10 > 0) ? "-" + unitsMap[number % 10] : "");
            }
            else if (number < 1000)
            {
                return unitsMap[number / 100] + " HUNDRED" + ((number % 100 > 0) ? " " + ConvertToWords(number % 100) : "");
            }
            else if (number < 1000000)
            {
                return ConvertToWords(number / 1000) + " THOUSAND" + ((number % 1000 > 0) ? " " + ConvertToWords(number % 1000) : "");
            }
            else if (number < 1000000000)
            {
                return ConvertToWords(number / 1000000) + " MILLION" + ((number % 1000000 > 0) ? " " + ConvertToWords(number % 1000000) : "");
            }
            else if (number < 1000000000000)
            {
                return ConvertToWords(number / 1000000000) + " BILLION" + ((number % 1000000000 > 0) ? " " + ConvertToWords(number % 1000000000) : "");
            }
            else
            {
                return ConvertToWords(number / 1000000000000) + " TRILLION" + ((number % 1000000000000 > 0) ? " " + ConvertToWords(number % 1000000000000) : "");
            }
        }
    }

    public class NumberInputModel
    {
        public string NumberInput { get; set; }
    }
}
